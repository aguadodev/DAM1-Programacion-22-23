public class Pasajero extends Persona{

    public Pasajero(String nombre) {
        super(nombre);
    }
    
}
